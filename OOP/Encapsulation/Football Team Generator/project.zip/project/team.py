from project.player import Player

class Team:
    def __init__(self,name,rating):
        self.__name = name
        self.__rating = rating
        self.__players: list[Player] = []

    def add_player(self,player: Player):
        if player not in self.__players:
            self.__players.append(player)
            return f"Player {player.name} joined team {self.__name}"
        return f"Player {player.name} has already joined"

    def remove_player(self,player_name: str):
        removed_player = next((p for p in self.__players if p.name == player_name), None)
        if removed_player:
            self.__players.remove(removed_player)
            return removed_player
        return f"Player {player_name} not found"

